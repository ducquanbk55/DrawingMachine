﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO.Ports;
namespace DrawingMachine
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SerialPort port1;
        byte posX = 0;
        byte posY = 0;
        public MainWindow()
        {
            InitializeComponent();
            port1 = new SerialPort();
            port1.PortName = "COM5";
            port1.BaudRate = 115200;
            port1.DataBits = 8;
            port1.StopBits = StopBits.One;
            port1.Parity = Parity.None;
            port1.Open();
            port1.DataReceived += Port1_DataReceived;
        }

        private void Port1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            System.Threading.Thread.Sleep(30);
            int bytes = port1.BytesToRead;
            byte[] buffer = new byte[bytes];
            port1.Read(buffer, 0, bytes);
            string content = "";
            foreach (var item in buffer)
            {
                content += BYTE2STR(item)+" ";
            }
            this.Dispatcher.Invoke((Action)(()=> {
                txtterminal.Text = content;
            }));
        }

        private void btnstart_Click(object sender, RoutedEventArgs e)
        {
            string content = txtcontent.Text;
            string[] _content = content.Split(' ');
            byte[] buffer = new byte[_content.Length];
            for (int i = 0; i < buffer.Length; i++)
            {
                buffer[i] = STR2BYTE(_content[i]);
            }
            port1.Write(buffer, 0, buffer.Count());
        }
        private byte STR2BYTE(string obj)
        {
            return Convert.ToByte(obj, 16);
        }
        private string BYTE2STR(byte obj)
        {
            return obj.ToString("x");
        }

        private void btnholdfw_Click(object sender, RoutedEventArgs e)
        {
            if(posY<255)
                posY++;
            port1.Write(new byte[] {0x7e, 0, 0, posY}, 0, 1);
        }

        private void btnholdbw_Click(object sender, RoutedEventArgs e)
        {
            if (posY > 0)
                posY--;
            port1.Write(new byte[] { 0x7e, 0, 1, posY }, 0, 1);
        }
    }
}
